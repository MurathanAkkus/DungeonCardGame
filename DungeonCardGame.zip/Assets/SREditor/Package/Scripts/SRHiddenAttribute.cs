using System;

namespace SerializeReferenceEditor
{
	[AttributeUsage(AttributeTargets.Class)]
	public class SRHiddenAttribute : Attribute
	{
	}
}