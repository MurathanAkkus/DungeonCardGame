// Tepki zamanlamas�n� belirtir.
public enum ReactionTiming
{
    PRE, // �nceki tepki
    POST // Sonraki tepki
}
