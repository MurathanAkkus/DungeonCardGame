public interface IHaveCaster
{
    CombatantView Caster { get; }
}
