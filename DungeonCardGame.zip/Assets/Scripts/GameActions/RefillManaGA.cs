using UnityEngine;

public class RefillManaGA : GameAction
{
    
}
