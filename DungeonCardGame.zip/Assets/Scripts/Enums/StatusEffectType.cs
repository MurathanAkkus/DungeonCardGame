public enum StatusEffectType
{
    ARMOR,
    BURN,
    STRENGTH
}