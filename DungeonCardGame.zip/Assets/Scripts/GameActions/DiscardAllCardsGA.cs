using UnityEngine;

public class DiscardAllCardsGA : GameAction
{
    
}