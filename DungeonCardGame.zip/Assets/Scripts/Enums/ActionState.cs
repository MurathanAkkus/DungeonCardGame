public enum ActionState
{
    Idle,
    Performing,
    Completed,
    Error
}